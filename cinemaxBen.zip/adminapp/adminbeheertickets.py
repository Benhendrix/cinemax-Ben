import prettytable
import os
from models.ticket import Ticket
from db.datamanager import Datamanager
from prettytable import PrettyTable
from ansimarkup import ansiprint as print
import os
def beheer_tickets():
    pass